document.getElementById('light-01').addEventListener('change', function() {
	if (this.checked) {
		alert('客厅灯光已打开');
	} else {
		alert('客厅灯光已关闭');
	}
});

document.getElementById('ac-01').addEventListener('change', function() {
	if (this.checked) {
		alert('客厅空调已打开');
	} else {
		alert('客厅空调已关闭');
	}
});

document.getElementById('tv-01').addEventListener('change', function() {
	if (this.checked) {
		alert('客厅电视已打开');
	} else {
		alert('客厅电视已关闭');
	}
});

document.getElementById('light-02').addEventListener('change', function() {
	if (this.checked) {
		alert('主卧灯光已打开');
	} else {
		alert('主卧灯光已关闭');
	}
});

document.getElementById('ac-02').addEventListener('change', function() {
	if (this.checked) {
		alert('主卧空调已打开');
	} else {
		alert('主卧空调已关闭');
	}
});
